PYTHON=python
$PYTHON Trainer.py --model=Node2Vec --ratio=5 --dataset=contact-high-school

$PYTHON Trainer.py --model=Node2Vec --ratio=5 --dataset=email-enron

$PYTHON Trainer.py --model=Node2Vec --ratio=5 --dataset=contact-primary-school

$PYTHON Trainer.py --model=Node2Vec --ratio=5 --dataset=DBLP

$PYTHON Trainer.py --model=Node2Vec --ratio=5 --dataset=math-sx

$PYTHON Trainer.py --model=Node2Vec --ratio=5 --dataset=MAG-Geo

$PYTHON Trainer.py --model=Node2Vec --ratio=5 --dataset=NDC

$PYTHON Trainer.py --model=Node2Vec --ratio=5 --dataset=DAWN
