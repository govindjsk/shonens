PYTHON=python
$PYTHON SHONeN.py --ratio=5 --dataset=contact-high-school

$PYTHON SHONeN.py --ratio=5 --dataset=email-enron

$PYTHON SHONeN.py --ratio=5 --dataset=NDC --trainable-embeddings=False --max-subset-size=6

$PYTHON SHONeN.py --ratio=5 --dataset=DAWN --trainable-embeddings=False --max-subset-size=6

$PYTHON SHONeN.py --ratio=5 --dataset=contact-primary-school

$PYTHON SHONeN.py --ratio=5 --dataset=DBLP

$PYTHON SHONeN.py --ratio=5 --dataset=math-sx

$PYTHON SHONeN.py --ratio=5 --dataset=MAG-Geo
