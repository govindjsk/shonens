This dataset is derived from the Microsoft Academic Graph available as part of
the Open Academic Graph. The raw data was downloaded from
https://www.openacademic.ai/oag/

Each simplex corresponds to a publication whose field of study includes the tag
"Geology". Each node in a simplex is an author on the publication. A timestamp
is the year of publication.

The file coauth-MAG-Geology-node-labels.txt maps the node IDs to authors.

The nth line in coauth-MAG-Geology-simplex-labels.txt is the title
of the publication corresponding to the nth simplex.
